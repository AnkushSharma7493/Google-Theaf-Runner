/*import Runner.Coordinates;
import Runner.Node;

public class NickTraverseGraph {

	private static Coordinates Nicklocation;

	private static Coordinates[] trucks;
	private static int truckCount = 0;

	private static Coordinates safelocation;
	private static char[][] grid;
	private static boolean[][] visited;
	private static int NickTime;
	static final long abc = 1l;

	private static Node start;
	
 	private static void calculateDistance() {
	boolean samerow = false;
	boolean sameColumn = false;

	if (Nicklocation.getX() == safelocation.getX()) {
		samerow = true;
	}
	if (Nicklocation.getY() == safelocation.getY()) {
		sameColumn = true;
	}

	while (Nicklocation.getX() != safelocation.getX() && Nicklocation.getY() != Nicklocation.getY()) {
		int x = Nicklocation.getX();
		int y = Nicklocation.getY();
		visited[x][y] = true;

		if (samerow) {
			// calculate move right or left
			int direction = safelocation.getY() - Nicklocation.getY();

			// move right
			if (direction > 0) {

				if (grid[x][y + 1] == 'O' && !visited[x][y]) {
					Nicklocation.setY(++y);
					visited[x][y] = true;
					NickTime++;
				} else if (grid[x][y + 1] == 'H' || grid[x][y + 1] == 'L' || grid[x][y + 1] == 'C') {
					// check down
					if (grid[x + 1][y] == 'O') {
						Nicklocation.setX(++x);
						if (visited[x][y]) {
							NickTime--;
						} else {
							visited[x][y] = true;
							NickTime++;
						}
					}
					// check down
					else if (grid[x - 1][y] == 'O') {
						Nicklocation.setX(--x);
						if (visited[x][y]) {
							NickTime--;
						} else {
							visited[x][y] = true;
							NickTime++;
						}
					}
					// check left
					else if (grid[x][y - 1] == 'O') {
						Nicklocation.setY(--y);
						if (visited[x][y]) {
							NickTime--;
						} else {
							visited[x][y] = true;
							NickTime++;
						}
					}
				} else if (grid[x][y] == 'S') {

				}
			} else if (direction < 0) {

			} else if (direction == 0) {

			}

			// calculate and check right adjacent
			y++;
			if (grid[x][y] == 'O') {
				Nicklocation.setY(y);
			}
		} else if (sameColumn) {
			// calculate and check Down adjacent
			x++;
			if (grid[x][y] == 'O') {
				Nicklocation.setY(y);
			}
		}

	}

}

}

class GNode
{
	int X;
	int Y;
	boolean visited;
	Node next;
	
public int getX() {
		return X;
	}
	public void setX(int x) {
		X = x;
	}
	public int getY() {
		return Y;
	}
	public void setY(int y) {
		Y = y;
	}
	public boolean isVisited() {
		return visited;
	}
	public void setVisited(boolean visited) {
		this.visited = visited;
	}
	public Node getNext() {
		return next;
	}
	public void setNext(Node next) {
		this.next = next;
	}
}
*/