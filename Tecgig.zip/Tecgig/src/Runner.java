import java.util.ArrayList;
import java.util.List;

public class Runner {

	private static Coordinates Nicklocation;

	private static Coordinates[] trucks;
	private static int truckCount = 0;

	private static Coordinates safelocation;
	private static char[][] grid;
	private static boolean[][] visited;
	private static int NickTime;
	private static long MinDistance = Integer.MAX_VALUE;

	private static Node start;

	public static void main(String[] args) {
		int diff;
		if ((diff = 5-3) > 0) {
System.out.println("Working " + diff);
		} 

	}

	public static int maxPossibleWait(int size, int steps, String[] rows) {
		grid = new char[rows.length][rows.length];
		initializeGrid(rows);
		// Initialize Nick traversal graph
		initializeNicktraversalgraph();

		return 0;
	}

	public static String[] getDirection() {
		String[] direction;

		int relativeY = safelocation.getY() - Nicklocation.getY();
		int relativeX = safelocation.getX() - Nicklocation.getX();

		if (relativeX > 0) {
		}
		if (Nicklocation.getY() == safelocation.getY()) {
		}

		return null;
	}

	public static void addNode(Coordinates coordinates, Node node) {
		Node next = new Node(coordinates);
		next.setVisited(true);
		next.setDistance(node.getDistance() + 1);
		node.getNext().add(next);
		if (grid[next.getCoordinate().getX()][node.getCoordinate().getY()] == 'S') {
			if (MinDistance > next.getDistance()) {
				MinDistance = next.getDistance();
			}
		} else {
			findpath(next);
		}
	}

	public static void findpath(Node node) {
		// check left
		if (node.getCoordinate().getY() >= 0
				&& (grid[node.getCoordinate().getX()][node.getCoordinate().getY() - 1] == 'O'
						|| grid[node.getCoordinate().getX()][node.getCoordinate().getY() - 1] == 'S')
				&& !node.isVisited()) {
			Coordinates coordinates = new Coordinates(node.getCoordinate().getX(), node.getCoordinate().getY() - 1);
			addNode(coordinates, node);
		}

		// check right
		if (node.getCoordinate().getY() < grid.length
				&& (grid[node.getCoordinate().getX()][node.getCoordinate().getY() + 1] == 'O'
						|| grid[node.getCoordinate().getX()][node.getCoordinate().getY() + 1] == 'S')
				&& !node.isVisited()) {
			Coordinates coordinates = new Coordinates(node.getCoordinate().getX(), node.getCoordinate().getY() + 1);
			addNode(coordinates, node);
		}

		// check up
		if (node.getCoordinate().getX() >= 0
				&& (grid[node.getCoordinate().getX() - 1][node.getCoordinate().getY()] == 'O'
						|| grid[node.getCoordinate().getX() - 1][node.getCoordinate().getY()] == 'S')
				&& !node.isVisited()) {
			Coordinates coordinates = new Coordinates(node.getCoordinate().getX() - 1, node.getCoordinate().getY());
			addNode(coordinates, node);
		}

		// check down
		if (node.getCoordinate().getY() < grid.length
				&& (grid[node.getCoordinate().getX() + 1][node.getCoordinate().getY()] == 'O'
						|| grid[node.getCoordinate().getX() + 1][node.getCoordinate().getY()] == 'S')
				&& !node.isVisited()) {
			Coordinates coordinates = new Coordinates(node.getCoordinate().getX() + 1, node.getCoordinate().getY());
			addNode(coordinates, node);
		}

	}

	private static void calculateDistance() {
		boolean samerow = false;
		boolean sameColumn = false;

		if (Nicklocation.getX() == safelocation.getX()) {
			samerow = true;
		}
		if (Nicklocation.getY() == safelocation.getY()) {
			sameColumn = true;
		}

		while (Nicklocation.getX() != safelocation.getX() && Nicklocation.getY() != Nicklocation.getY()) {
			int x = Nicklocation.getX();
			int y = Nicklocation.getY();
			visited[x][y] = true;

			if (samerow) {
				// calculate move right or left
				int direction = safelocation.getY() - Nicklocation.getY();

				// move right
				if (direction > 0) {

					if (grid[x][y + 1] == 'O' && !visited[x][y]) {
						Nicklocation.setY(++y);
						visited[x][y] = true;
						NickTime++;
					} else if (grid[x][y + 1] == 'H' || grid[x][y + 1] == 'L' || grid[x][y + 1] == 'C') {
						// check down
						if (grid[x + 1][y] == 'O') {
							Nicklocation.setX(++x);
							if (visited[x][y]) {
								NickTime--;
							} else {
								visited[x][y] = true;
								NickTime++;
							}
						}
						// check down
						else if (grid[x - 1][y] == 'O') {
							Nicklocation.setX(--x);
							if (visited[x][y]) {
								NickTime--;
							} else {
								visited[x][y] = true;
								NickTime++;
							}
						}
						// check left
						else if (grid[x][y - 1] == 'O') {
							Nicklocation.setY(--y);
							if (visited[x][y]) {
								NickTime--;
							} else {
								visited[x][y] = true;
								NickTime++;
							}
						}
					} else if (grid[x][y] == 'S') {

					}
				} else if (direction < 0) {

				} else if (direction == 0) {

				}

				// calculate and check right adjacent
				y++;
				if (grid[x][y] == 'O') {
					Nicklocation.setY(y);
				}
			} else if (sameColumn) {
				// calculate and check Down adjacent
				x++;
				if (grid[x][y] == 'O') {
					Nicklocation.setY(y);
				}
			}

		}

	}

	public static void initializeGrid(String[] rows) {
		for (int i = 0; i < rows.length; i++) {
			char[] temp = rows[i].toCharArray();
			for (int j = 0; j < temp.length; j++) {
				switch (temp[j]) {
				case 'M':
					Nicklocation = new Coordinates(i, j);
					break;
				case 'L':
					trucks[truckCount] = new Coordinates(i, j);
					truckCount++;
					break;
				case 'S':
					safelocation = new Coordinates(i, j);
					break;
				}
				grid[i][j] = temp[j];
			}
		}
	}

	public static void initializeNicktraversalgraph() {
		start = new Node(new Coordinates(Nicklocation.getX(), Nicklocation.getY()));
		addNode(start);
	}

	public static void addNode(Node node) {
		int x = node.getCoordinate().getX();
		int y = node.getCoordinate().getY();

		if (y + 1 < grid.length && (grid[x][y + 1] == 'O' || grid[x][y + 1] == 'S') && !visited[x][y + 1]) {
			Node Rnode = new Node(new Coordinates(x, ++y));
			visited[x][y] = true;
			node.getNext().add(Rnode);
			if (grid[x][y] != 'S')
				addNode(Rnode);
		} else if (y - 1 >= 0 && (grid[x][y - 1] == 'O' || grid[x][y - 1] == 'S') && !visited[x][y - 1]) {
			Node Lnode = new Node(new Coordinates(x, --y));
			visited[x][y] = true;
			node.getNext().add(Lnode);
			if (grid[x][y] != 'S')
				addNode(Lnode);
		} else if (x + 1 < grid.length && (grid[x + 1][y] == 'O' || grid[x + 1][y] == 'S') && !visited[x + 1][y]) {
			Node Dnode = new Node(new Coordinates(++x, y));
			visited[x][y] = true;
			node.getNext().add(Dnode);
			if (grid[x][y] != 'S')
				addNode(Dnode);
		} else if (x - 1 >= 0 && (grid[x - 1][y] == 'O' || grid[x - 1][y - 1] == 'S') && !visited[x - 1][y]) {
			--x;
			addnextNode(node, x, y);
		} else {

		}
	}

	public static void addnextNode(Node node, int x, int y) {
		Node Unode = new Node(new Coordinates(x, y));
		visited[x][y] = true;
		node.getNext().add(Unode);
		if (grid[x][y] != 'S')
			addNode(Unode);
	}

	static class Coordinates {
		public Coordinates() {
		}

		public Coordinates(int x, int y) {
			super();
			X = x;
			Y = y;
		}

		private int X;
		private int Y;

		public int getX() {
			return X;
		}

		public void setX(int x) {
			X = x;
		}

		public int getY() {
			return Y;
		}

		public void setY(int y) {
			Y = y;
		}
	}

	static class Node {
		private Coordinates coordinate;
		private boolean visited;
		private int distance;
		private List<Node> next;

		{
			next = new ArrayList<Runner.Node>();
		}

		public int getDistance() {
			return distance;
		}

		public void setDistance(int distance) {
			this.distance = distance;
		}

		public Node() {
		}

		public Node(Coordinates coordinate) {
			super();
			this.coordinate = coordinate;
		}

		public Coordinates getCoordinate() {
			return coordinate;
		}

		public void setCoordinate(Coordinates coordinate) {
			this.coordinate = coordinate;
		}

		public boolean isVisited() {
			return visited;
		}

		public void setVisited(boolean visited) {
			this.visited = visited;
		}

		public List<Runner.Node> getNext() {
			return next;
		}

		public void setNext(List<Runner.Node> next) {
			this.next = next;
		}
	}

}
