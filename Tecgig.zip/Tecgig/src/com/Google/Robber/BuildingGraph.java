package com.Google.Robber;

import java.util.List;

public class BuildingGraph {
	private static final BuildingGraph buildingGraph;
	private static Node[][] buiding;
	private static int length;
	private static List<Node> shortestPath;
	private static Coordinates[] trucks;
	private static int stepsPerMinute;
	private static int waitingTime;
	private static Coordinates Nicklocation;
	private static Coordinates safelocation;
	private static int truckCount;
	private static boolean isPathExist = false;
	private static boolean canNickWait = false;
	private static int clockMinute;

	private BuildingGraph() {
	}

	static {
		buildingGraph = new BuildingGraph();
	}

	public static BuildingGraph getBuildingGraph(int size) {
		if (buildingGraph.buiding == null) {
			buildingGraph.buiding = new Node[size][size];
			buildingGraph.length = size;
		}
		return buildingGraph;
	}

	public static BuildingGraph getBuildingGraph() throws Exception {
		if (buildingGraph.buiding == null) {
			throw new Exception("Building size is unknow, provide size in getBuildingGraph(int size)  methode !");
		}
		return buildingGraph;
	}

	// create node and add into builder array
	public void addNode(int x, int y, char value) {
		buiding[x][y] = new Node(new Coordinates(x, y), value);
	}

	public Node getNode(int x, int y) {
		return buiding[x][y];
	}

	public Node getNode(Coordinates coordinates) {
		return buiding[coordinates.getX()][coordinates.getY()];
	}

	public int getLength() {
		return length;
	}

	public static List<Node> getShortestPath() {
		return shortestPath;
	}

	public static void setShortestPath(List<Node> shortestPath) {
		BuildingGraph.shortestPath = shortestPath;
	}

	public static Coordinates[] getTrucks() {
		return trucks;
	}

	public static void setTrucks(Coordinates trucks, int index) {
		BuildingGraph.trucks[index] = trucks;
	}

	public static int getStepsPerMinute() {
		return stepsPerMinute;
	}

	public static void setStepsPerMinute(int stepsPerMinute) {
		BuildingGraph.stepsPerMinute = stepsPerMinute;
	}

	public static int getWaitingTime() {
		return waitingTime;
	}

	public static void setWaitingTime(int waitingTime) {
		BuildingGraph.waitingTime = waitingTime;
	}

	public static void setLength(int length) {
		BuildingGraph.length = length;
	}

	public static Node[][] getBuiding() {
		return buiding;
	}

	public static void setBuiding(Node[][] buiding) {
		BuildingGraph.buiding = buiding;
	}

	public static Coordinates getNicklocation() {
		return Nicklocation;
	}

	public static void setNicklocation(Coordinates nicklocation) {
		Nicklocation = nicklocation;
	}

	public static Coordinates getSafelocation() {
		return safelocation;
	}

	public static void setSafelocation(Coordinates safelocation) {
		BuildingGraph.safelocation = safelocation;
	}

	public static void setTrucks(Coordinates[] trucks) {
		BuildingGraph.trucks = trucks;
	}

	public static int getTruckCount() {
		return truckCount;
	}

	public static void setTruckCount(int truckCount) {
		BuildingGraph.truckCount = truckCount;
	}

	public static boolean isPathExist() {
		return isPathExist;
	}

	public static void setPathExist(boolean isPathExist) {
		BuildingGraph.isPathExist = isPathExist;
	}

	public static int getClockMinute() {
		return clockMinute;
	}

	public static void setClockMinute(int clockMinute) {
		BuildingGraph.clockMinute = clockMinute;
	}
}
