package com.Google.Robber;

class Coordinates {
	public Coordinates() {
	}

	public Coordinates(int x, int y) {
		super();
		X = x;
		Y = y;
	}

	private int X;
	private int Y;

	public int getX() {
		return X;
	}

	public void setX(int x) {
		X = x;
	}

	public int getY() {
		return Y;
	}

	public void setY(int y) {
		Y = y;
	}
}
