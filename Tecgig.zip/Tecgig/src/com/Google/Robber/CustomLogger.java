package com.Google.Robber;

public class CustomLogger {
// write all output of program into seprate log file, in append or overwrite mode.
}
