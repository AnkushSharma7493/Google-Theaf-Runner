package com.Google.Robber;

import java.util.concurrent.CopyOnWriteArrayList;

/*
 * 				ANKUSH SHARMA Alogorith USING DYNAMIC PROGRAMMING 
 * STEP 0 : DEVELOP DATA STRUCTURE FOR THE PROBLEM.(MATRICX OF NODE TYPES), ALSO DEVELOP A SINGLETON OBJECT BuildingGraph AT APPLICATIONCONTEXT LEVEL,WHICH COMPRISES ALL
 * 			LOCATION DETAIL FOR ALL THE THREADS :: O(NUMBER OF CELL).
 * Step 1 : CALCULATE THE RELATIVE MATRIX WRT SAFE LOCATION (Calculating distance of each cell from the safe location) :: TimeComplexity : O(NUMBER OF CELL).
 * STEP 2 : CALCULATE MIN TIME FOR NICK TO REACH THE SAFE LOCATION CALLED NICKSAFETIME(Which is the relative matrix cell value itself) : O(1).
 * STEP 3 : START THE COPS EXPANSION THREAD FOR THE TIME EQUALS TO NICKSAFETIME, WHICH MODIFY THE SINGLETION BUIDING OBJECT FOR COPS LOCATONS.
 * STEP 4 : CHECK THE GENERATED MATRIX IF THERE IS ANY PATH EXIST FOR NICK TO REACH SAFE LOCATION, BY SIMPLE FOLLOWING THE DECENDING ORDER OF DISTANCE FROM SAFE LOCATION(CALCULATE IN STEP 2).
 * STEP 5 : IF PATH DOES NOT EXIST, RETURN -1
 * STEP 6 : IF PATH EXIST , THEN CALL THE COPS THREAD FOR 1 MINUTE  AND INCREMENT WAITING_TIME VARIABLE BY 1 AND CHECK AGAIN IF PATH EXIST, REPEAT UNTILL NICK GOT CAUGHT.
 * STEP 7 : ONCE MATRIX STATE GENERATED IN WHICH THERE IS NO PATH EXIST BETWEEN NICK AND SAFE LOCATION, RETURN WAITINNG_TIME-1;
 * 
 * */

public class DynamicApproch {
	private static Coordinates Nicklocation;
	private static int truckCount;
	private static Coordinates safelocation;
	private static BuildingGraph buildingGraph;
	private static CopyOnWriteArrayList<Coordinates> truckList = new CopyOnWriteArrayList<>();
	private static int waitingTime = 0;
	private static CopyOnWriteArrayList<Coordinates> copsLocation;

	public static int start(int size, int steps, String[] rows) throws Exception {
		// STEP 0
		initializeGrid(rows);

		// STEP 1
		Node safe = buildingGraph.getNode(safelocation.getX(), safelocation.getY());
		safe.setDistance(0);
		safe.setVisited(true);
		calculateRelativeCoordinates(safe);

		// UPDATE THE SINGLETON BUILDING GRAPH OBJECT
		buildingGraph.setStepsPerMinute(steps);
		buildingGraph.setNicklocation(Nicklocation);
		buildingGraph.setSafelocation(safelocation);
		buildingGraph.setTruckCount(truckCount);

		// STEP2
		int NickSafeTime = (buildingGraph.getNode(buildingGraph.getNicklocation()).getDistance()
				+ buildingGraph.getStepsPerMinute() - 1) / buildingGraph.getStepsPerMinute();

		// STEP 3
		copsLocation = new CopyOnWriteArrayList<>();
		copsLocation.addAll(truckList);
		checkCopsSpreadRate(NickSafeTime);

		// PAUSE MAIN THREAD MEANWHILE COPS EXPANSION
		Thread[] allThread = new Thread[Thread.currentThread().getThreadGroup().activeCount()];
		Thread.currentThread().getThreadGroup().enumerate(allThread);
		for (Thread thread : allThread) {
			if ("COP-THREAD".equals(thread.getName())) {
				thread.join();
			}
		}

		// STEP 4
		findAllPaths(buildingGraph.getNode(Nicklocation));

		// STEP 5
		if (!BuildingGraph.getBuildingGraph().isPathExist()) {
			return -1;
		}

		// STEP 6
		while (BuildingGraph.getBuildingGraph().isPathExist()) {
			checkNickLuckForNextMinute();
		}

		// STEP 7
		waitingTime--;
		return waitingTime;

	}

	public static void initializeGrid(String[] rows) throws Exception {
		buildingGraph = BuildingGraph.getBuildingGraph(rows.length);
		for (int i = 0; i < rows.length; i++) {
			char[] temp = rows[i].toCharArray();
			for (int j = 0; j < temp.length; j++) {
				switch (temp[j]) {
				case 'M':
					Nicklocation = new Coordinates(i, j);
					break;
				case 'L':
					// buildingGraph.setTrucks(new Coordinates(i, j), truckCount);
					truckList.add(new Coordinates(i, j));
					truckCount++;
					break;
				case 'S':
					safelocation = new Coordinates(i, j);
					break;
				}
				buildingGraph.addNode(i, j, temp[j]);
			}
		}
	}

	public static void findpath(Node node) {
		int x = node.getCoordinate().getX();
		int y = node.getCoordinate().getY();
		Node next;

		// check right
		if (y + 1 < buildingGraph.getLength()) {
			next = buildingGraph.getNode(x, y + 1);
			updateNode(next, node);
		}
		// check left
		if (y - 1 >= 0) {
			next = buildingGraph.getNode(x, y - 1);
			updateNode(next, node);
		}

		// check up
		if (x - 1 >= 0) {
			next = buildingGraph.getNode(x - 1, y);
			updateNode(next, node);
		}

		// check down

		if (x + 1 < buildingGraph.getLength()) {
			next = buildingGraph.getNode(x + 1, y);
			updateNode(next, node);
		}
	}

	public static void updateNode(Node next, Node node) {
		if ((next.getValue() == 'O' || next.getValue() == 'M' || next.getValue() == 'H' || next.getValue() == 'L')
				&& !next.isVisited()) {
			next.setVisited(true);
			next.setDistance(node.getDistance() + 1);
			findpath(next);
		}
	}

	public static void calculateRelativeDistanceMatrix(Node node) {
		int distanceRow = node.getDistance();

		for (int i = node.getCoordinate().getY(); i >= 0; i--) {
			buildingGraph.getNode(0, i).setDistance(distanceRow);
			int distanceCol = distanceRow;
			for (int j = 1; j < buildingGraph.getLength(); j++) {
				buildingGraph.getNode(j, i).setDistance(++distanceCol);
			}
			distanceRow++;
		}
	}

	// Calculate the relative coordinate wrt safe location
	public static void calculateRelativeCoordinates(Node safe) {
		for (int i = 0; i < buildingGraph.getLength(); i++) {
			for (int j = 0; j < buildingGraph.getLength(); j++) {
				Node node = buildingGraph.getNode(i, j);
				node.setRelativeCoordinate(
						new Coordinates(Math.abs(node.getCoordinate().getX() - safe.getCoordinate().getX()),
								Math.abs(node.getCoordinate().getY() - safe.getCoordinate().getY())));
				node.setDistance(node.getRelativeCoordinate().getX() + node.getRelativeCoordinate().getY());
			}
		}
		safe.setRelativeCoordinate(new Coordinates(0, 0));
	}

	public static void checkCopsSpreadRate(int time) {
		new Thread("COP-THREAD") {
			public void run() {
				for (int currentMinute = 1; currentMinute <= time; currentMinute++) {
					buildingGraph.setClockMinute(buildingGraph.getClockMinute() + 1);
					// cop location collection can be optimize by remove cops which will never
					// spread and only allowing cornered cops in the collection
					for (Coordinates coordinates : copsLocation) {
						setCop(coordinates);
					}
				}
			}
		}.start();
	}

	public static void setCop(Coordinates truck) {
		// check right
		if (truck.getY() + 1 < buildingGraph.getLength()) {
			locateCop(truck.getX(), truck.getY() + 1);
		}
		// check left
		if (truck.getY() - 1 >= 0) {
			locateCop(truck.getX(), truck.getY() - 1);
		}

		// check up
		if (truck.getX() - 1 >= 0) {
			locateCop(truck.getX() - 1, truck.getY());
		}

		// check down
		if (truck.getX() + 1 < buildingGraph.getLength()) {
			locateCop(truck.getX() + 1, truck.getY());
		}
	}

	public static void locateCop(int x, int y) {
		if ((buildingGraph.getNode(x, y).getValue() == 'O' || buildingGraph.getNode(x, y).getValue() == 'M')
				&& !buildingGraph.getNode(x, y).isVisited()) {
			buildingGraph.getNode(x, y).setValue('C');
			buildingGraph.getNode(x, y).setCopArrivalTime(buildingGraph.getClockMinute());
			buildingGraph.getNode(x, y).setVisited(true);
			copsLocation.add(new Coordinates(x, y));
		}
	}

	public static void findAllPaths(Node source) {
		// check left
		if (source.getCoordinate().getY() - 1 >= 0
				&& buildingGraph.getNode(source.getCoordinate().getX(), source.getCoordinate().getY() - 1)
						.getDistance() < source.getDistance()) {
			processPath(source.getCoordinate().getX(), source.getCoordinate().getY() - 1);
		}
		// check right
		if (source.getCoordinate().getY() + 1 < buildingGraph.getLength()
				&& buildingGraph.getNode(source.getCoordinate().getX(), source.getCoordinate().getY() + 1)
						.getDistance() < source.getDistance()) {
			processPath(source.getCoordinate().getX(), source.getCoordinate().getY() + 1);
		}
		// check up
		if (source.getCoordinate().getX() - 1 >= 0
				&& buildingGraph.getNode(source.getCoordinate().getX() - 1, source.getCoordinate().getY())
						.getDistance() < source.getDistance()) {
			processPath(source.getCoordinate().getX() - 1, source.getCoordinate().getY());
		}
		// check down
		if (source.getCoordinate().getX() + 1 < buildingGraph.getLength()
				&& buildingGraph.getNode(source.getCoordinate().getX() + 1, source.getCoordinate().getY())
						.getDistance() < source.getDistance()) {
			processPath(source.getCoordinate().getX() + 1, source.getCoordinate().getY());
		}
	}

	private static void processPath(int x, int y) {

		if ((buildingGraph.getNode(x, y).getValue() == 'O' || buildingGraph.getNode(x, y).getValue() == 'C'
				|| buildingGraph.getNode(x, y).getValue() == 'S') && !buildingGraph.isPathExist()) {

			if (buildingGraph.getNode(x, y).getValue() == 'S') {
				buildingGraph.setPathExist(true);
				System.out.println("Hurray Nick Escaped !");
			}

			/*
			 * if ((buildingGraph.getNode(x, y).getValue() == 'C' &&
			 * buildingGraph.getNode(x, y) .getCopArrivalTime() >
			 * findDistance(buildingGraph.getNode(Nicklocation).getCoordinate().getX(),
			 * x,buildingGraph.getNode(Nicklocation).getCoordinate().getY(), y) +
			 * waitingTime) || (buildingGraph.getNode(x, y).getValue() == 'O')) {
			 * findAllPaths(buildingGraph.getNode(x, y)); }
			 */
			if ((buildingGraph.getNode(x, y).getValue() == 'C' && buildingGraph.getNode(x, y)
					.getCopArrivalTime() > Math.abs(buildingGraph.getNode(Nicklocation).getDistance()
							- buildingGraph.getNode(x, y).getDistance()) + waitingTime)
					|| (buildingGraph.getNode(x, y).getValue() == 'O')) {
				findAllPaths(buildingGraph.getNode(x, y));
			}
		}
	}

	public static int findDistance(int x1, int x2, int y1, int y2) {
		return Math.abs(x2 - x1) + Math.abs(y2 - y1);
	}

	public static void checkNickLuckForNextMinute() throws Exception {
		// IN CASE OF WAITING MODE, COP ARRIVAL TIME CALCULATED AS USUAL , BUT NICK
		// ARRIVAL TIME WILL INCREMENT BY waitingTime VARIABLE.
		waitingTime++;
		checkCopsSpreadRate(1);
		System.out.println("COPS LOCATION FOR NEXT WAITING MINUTE");
		//NickHealper.showBuilding();
		BuildingGraph.setPathExist(false);
		findAllPaths(buildingGraph.getNode(Nicklocation));
	}
}
