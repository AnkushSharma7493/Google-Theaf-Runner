package com.Google.Robber;

public class MIBThread {
	private static BuildingGraph buildingGraph;
	private static boolean catchNick = false;

	{
		try {
			buildingGraph = BuildingGraph.getBuildingGraph();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean spreadCops(Coordinates truck) {
		int x = truck.getX();
		int y = truck.getY();
		// move left
		if (y - 1 >= 0 && (buildingGraph.getNode(x, y - 1).getValue() == 'O'
				|| buildingGraph.getNode(x, y - 1).getValue() == 'M')) {
			if (buildingGraph.getNode(x, y - 1).getValue() == 'M') {
				// computeSomeLogic();
			} else {
				buildingGraph.getNode(x, y - 1).setValue('C');
			}
		}

		// move right
		if (y + 1 >= 0 && (buildingGraph.getNode(x, y + 1).getValue() == 'O'
				|| buildingGraph.getNode(x, y + 1).getValue() == 'M')) {
			if (buildingGraph.getNode(x, y + 1).getValue() == 'M') {
				// computeSomeLogic();
			} else {
				buildingGraph.getNode(x, y + 1).setValue('C');
			}
		}

		// move up
		if (x - 1 >= 0 && (buildingGraph.getNode(x - 1, y).getValue() == 'O'
				|| buildingGraph.getNode(x - 1, y).getValue() == 'M')) {
			if (buildingGraph.getNode(x - 1, y).getValue() == 'M') {
				// computeSomeLogic();
				/*
				 * when first cob intersect the Nick pathway,
				 */
			} else {
				buildingGraph.getNode(x - 1, y).setValue('C');
			}
		}

		// move Down
		if (x + 1 >= 0 && (buildingGraph.getNode(x + 1, y).getValue() == 'O'
				|| buildingGraph.getNode(x + 1, y).getValue() == 'M')) {
			if (buildingGraph.getNode(x + 1, y).getValue() == 'M') {
				// computeSomeLogic();
			} else {
				buildingGraph.getNode(x + 1, y).setValue('C');
			}
		}
		return catchNick;
	}

	public void catchNickCal(Node copNode, Node nickNode) {

		int NickTime = nickNode.getDistance() / buildingGraph.getStepsPerMinute();
		int copTime = copNode.getDistance();
		int diff;
		if ((diff = copTime - NickTime) > 0) {
			// check if nick can wait
			if (diff > 1) {
				buildingGraph.setWaitingTime(--diff);
			}
		} else {
			catchNick = true;
		}
	}

}
