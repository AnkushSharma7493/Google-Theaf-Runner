package com.Google.Robber;

import com.techgig.ca.CandidateCode;
import com.techgig.ca.ExcapePlan;

public class MyTester {

	private static int size;
	private static int steps;
	private static String[] rows = { "OOHOOOOOLOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO",
			"OOSOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO",
			"OOOOOMOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO",
			"OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO",
			"OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO",
			"OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO",
			"OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO",
			"OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO",
			"OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOOOOOOOOOOOOOOOOOOOOOOO", "OOOOLOOOOOOOOOOOOOOOOOOOOO" };

	public static void main(String[] args) throws Exception {
		final long startTime = System.nanoTime();
		//Scenario 1 : nick canot escape
		Coordinates nick = new Coordinates(14, 0);
		Coordinates safe = new Coordinates(14, 14);
		Coordinates trucks[] = { new Coordinates(0, 0), new Coordinates(3, 1), new Coordinates(3, 4),
				new Coordinates(4, 5), new Coordinates(4, 6), new Coordinates(6, 9), new Coordinates(6, 1),
				new Coordinates(9, 4), new Coordinates(12, 8), };
		Coordinates hurdles[] = { new Coordinates(6, 4), new Coordinates(7, 4), new Coordinates(8, 10),
				new Coordinates(10, 3), new Coordinates(10, 10), new Coordinates(11, 11), new Coordinates(13, 5) };

		//Scanario 2 : Nick will escape with waiting time of 1 minute
		/*
		Coordinates nick = new Coordinates(0, 0);
		Coordinates safe = new Coordinates(0, 4);
		Coordinates trucks[] = { new Coordinates(4, 4), };
		Coordinates hurdles[] = {};
		*/
		
		//DynamicApproch.initializeGrid(new SampleTestCase(6).getTestCase(nick, safe, trucks, hurdles));
		//System.out.println("maximum waiting time by Dynamic Approch : "+DynamicApproch.start(5, 1, new SampleTestCase(5).getTestCase(nick, safe, trucks, hurdles)));
		//System.out.println("maximum waiting time by TechGIG Approch : "+CandidateCode.maxPossibleWait(15, 1, new SampleTestCase(15).getTestCase(nick, safe, trucks, hurdles)));
		System.out.println("maximum waiting time by TechGIG : "+CandidateCode.maxPossibleWait(26, 1, rows));
		final long duration = System.nanoTime() - startTime;

		//NickHealper.showBuilding();

		/*if (!BuildingGraph.getBuildingGraph().isPathExist()) {
			System.out.println("COPS COUGHT THE NICK");
		}*/
		System.out.println((double) duration / 1000000000.0 + " seconds ");

	}

}
