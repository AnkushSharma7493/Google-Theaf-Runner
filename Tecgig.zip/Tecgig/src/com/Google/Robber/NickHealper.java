package com.Google.Robber;

public class NickHealper {
	private static BuildingGraph buildingGraph;

	public static void showBuilding() throws Exception {
		//buildingGraph = BuildingGraph.getBuildingGraph();
		System.out.println();
		for (int i = 0; i < buildingGraph.getLength(); i++) {
			for (int j = 0; j < buildingGraph.getLength(); j++) {
				if (buildingGraph.getNode(i, j).getValue() == 'M' || buildingGraph.getNode(i, j).getValue() == 'S'
						|| buildingGraph.getNode(i, j).getValue() == 'L' || buildingGraph.getNode(i, j).getValue() == 'H' || buildingGraph.getNode(i, j).getValue() == 'C') {
					System.out.print(buildingGraph.getNode(i, j).getValue()+ "	");
				}else {
				System.out.print(buildingGraph.getNode(i, j).getDistance() + "	");}
			}
			System.out.println();
		}
	}

}
