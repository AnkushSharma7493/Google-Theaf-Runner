package com.Google.Robber;

import java.util.ArrayList;
import java.util.List;

public class Node {
	private Coordinates coordinate;
	private boolean visited;
	private Integer distance;
	private ArrayList<Node> path;
	private volatile Character value;
	private Coordinates relativeCoordinate;
	private int copArrivalTime;

	public Node() {
	}

	public Node(Coordinates coordinate) {
		super();
		this.coordinate = coordinate;
	}

	public Node(Coordinates coordinate, char value) {
		super();
		this.coordinate = coordinate;
		this.value = value;
	}

	public char getValue() {
		return value;
	}

	public void setValue(char value) {
		this.value = value;
	}

	public ArrayList<Node> getPath() {
		return path;
	}

	public void setPath(ArrayList<Node> path) {
		this.path = path;
	}

	{
		path = new ArrayList<Node>();
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public Coordinates getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(Coordinates coordinate) {
		this.coordinate = coordinate;
	}

	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}

	public Coordinates getRelativeCoordinate() {
		return relativeCoordinate;
	}

	public void setRelativeCoordinate(Coordinates relativeCoordinate) {
		this.relativeCoordinate = relativeCoordinate;
	}

	public int getCopArrivalTime() {
		return copArrivalTime;
	}

	public void setCopArrivalTime(int copArrivalTime) {
		this.copArrivalTime = copArrivalTime;
	}

}
