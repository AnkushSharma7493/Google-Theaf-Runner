package com.Google.Robber;

import java.util.List;

public class PropogateThread {
	private Coordinates Nicklocation;
	private Coordinates[] trucks;
	private int truckCount = 0;
	private Coordinates safelocation;
	private char[][] grid;
	private boolean[][] visited;
	private int NickTime;
	private long MinDistance = Integer.MAX_VALUE;
	private Node start;
	private List<Node> shortestPath;
	private List<Node> Path;
	private char[] pattern;

	public PropogateThread() {
	}

	public PropogateThread(char[] pattern) {
		this.pattern = pattern;
	}

	public void findpath(Node node) {

		// check left
		if (node.getCoordinate().getY() - 1 >= 0
				&& (grid[node.getCoordinate().getX()][node.getCoordinate().getY() - 1] == pattern[0]
						|| grid[node.getCoordinate().getX()][node.getCoordinate().getY() - 1] == pattern[1])
				&& !node.isVisited()) {
			Coordinates coordinates = new Coordinates(node.getCoordinate().getX(), node.getCoordinate().getY() - 1);
			addNode(coordinates, node);
		}

		// check right
		if (node.getCoordinate().getY() + 1 < grid.length
				&& (grid[node.getCoordinate().getX()][node.getCoordinate().getY() + 1] == pattern[0]
						|| grid[node.getCoordinate().getX()][node.getCoordinate().getY() + 1] == pattern[1])
				&& !node.isVisited()) {
			Coordinates coordinates = new Coordinates(node.getCoordinate().getX(), node.getCoordinate().getY() + 1);
			addNode(coordinates, node);
		}

		// check up
		if (node.getCoordinate().getX() >= 0
				&& (grid[node.getCoordinate().getX() - 1][node.getCoordinate().getY()] == pattern[0]
						|| grid[node.getCoordinate().getX() - 1][node.getCoordinate().getY()] == pattern[1])
				&& !node.isVisited()) {
			Coordinates coordinates = new Coordinates(node.getCoordinate().getX() - 1, node.getCoordinate().getY());
			addNode(coordinates, node);
		}

		// check down
		if (node.getCoordinate().getY() < grid.length
				&& (grid[node.getCoordinate().getX() + 1][node.getCoordinate().getY()] == pattern[0]
						|| grid[node.getCoordinate().getX() + 1][node.getCoordinate().getY()] == pattern[1])
				&& !node.isVisited()) {
			Coordinates coordinates = new Coordinates(node.getCoordinate().getX() + 1, node.getCoordinate().getY());
			addNode(coordinates, node);
		}

	}

	public void addNode(Coordinates coordinates, Node node) {
		Node next = new Node(coordinates);
		next.setVisited(true);
		next.setDistance(node.getDistance() + 1);
		next.getPath().add(next);
		next.getPath().addAll(node.getPath());
		if (grid[coordinates.getX()][coordinates.getY()] == 'S') {
			if (MinDistance > next.getDistance()) {
				MinDistance = next.getDistance();
				shortestPath = next.getPath();
			}
		} else {
			this.findpath(next);
		}
	}

}
