package com.Google.Robber;

import java.util.List;

public class RobberThread {
	private static Coordinates Nicklocation;
	private static int truckCount;
	private static Coordinates safelocation;
	private static long MinDistance = Integer.MAX_VALUE;
	private static Node start;
	private static BuildingGraph buildingGraph;
	private static List<Node> Path;

	public static void initializeGrid(String[] rows) {
		buildingGraph = BuildingGraph.getBuildingGraph(rows.length);
		for (int i = 0; i < rows.length; i++) {
			char[] temp = rows[i].toCharArray();
			for (int j = 0; j < temp.length; j++) {
				switch (temp[j]) {
				case 'M':
					Nicklocation = new Coordinates(i, j);
					break;
				case 'L':
					buildingGraph.setTrucks(new Coordinates(i, j), truckCount);
					truckCount++;
					break;
				case 'S':
					safelocation = new Coordinates(i, j);
					break;
				}
				// grid[i][j] = temp[j];
				buildingGraph.addNode(i, j, temp[j]);
			}
		}	
		
		

		// initialize start node and find the shortest path and followed path node
		start = new Node(Nicklocation);
		start.setDistance(0);
		start.getPath().add(start);
		start.setVisited(true);
		findpath(start);

		// mark the final path
		for (Node node : buildingGraph.getShortestPath()) {
			{
				buildingGraph.getNode(node.getCoordinate().getX(), node.getCoordinate().getY()).setValue('M');
				System.out.println("(" + node.getCoordinate().getX() + "," + node.getCoordinate().getY() + ")");
			}
		}
	}

	public static void findpath(Node node) {
		int x = node.getCoordinate().getX();
		int y = node.getCoordinate().getY();
		Node next;

		// check right
		if (y + 1 < buildingGraph.getLength()) {
					next = buildingGraph.getNode(x, y + 1);
					updateNode(next, node);
				}
		// check left
		if (y - 1 >= 0) {
			next = buildingGraph.getNode(x, y - 1);
			updateNode(next, node);
		}

		// check up
		if (x - 1 >= 0) {
			next = buildingGraph.getNode(x - 1, y);
			updateNode(next, node);
		}

		// check down

		if (x + 1 < buildingGraph.getLength()) {
			next = buildingGraph.getNode(x + 1, y);
			updateNode(next, node);
		}
	}

	public static void updateNode(Node next, Node node) {
		if ((next.getValue() == 'O' || next.getValue() == 'S') && !next.isVisited()) {
			next.setVisited(true);
			next.setDistance(node.getDistance() + 1);
			next.getPath().add(next);
			next.getPath().addAll(node.getPath());
			if (next.getValue() == 'S') {
				if (MinDistance > next.getDistance()) {
					MinDistance = next.getDistance();
					buildingGraph.setShortestPath(next.getPath());
				}
			} else {
				findpath(next);
			}
		}
	}
}
