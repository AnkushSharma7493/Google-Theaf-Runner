package com.Google.Robber;

public class SampleTestCase {

	private static String[] testCaseString;

	SampleTestCase() {
	}

	public SampleTestCase(int size) {
		testCaseString = new String[size];
	}

	public String[] getTestCase(Coordinates nick, Coordinates safe, Coordinates[] trucks, Coordinates[] hurdles) {
		// to optimise the complexity, we can sort the truck array and allocate the
		// first coordinate first and then proceed with the next and so on.
		for (int i = 0; i < testCaseString.length; i++) {
			StringBuffer row = new StringBuffer();
			for (int j = 0; j < testCaseString.length; j++) {
				if (nick.getX() == i && nick.getY() == j) {
					row.append("M");
				} else if (safe.getX() == i && safe.getY() == j) {
					row.append("S");
				} else if (isFound(i, j, trucks)) {
					row.append("L");
				} else if (isFound(i, j, hurdles)) {
					row.append("H");
				} else {
					row.append("O");
				}
			}
			testCaseString[i] = row.toString();
		}

		return testCaseString;
	}

	private boolean isFound(int i, int j, Coordinates[] coordinates) {
		for (Coordinates coordinate : coordinates) {
			if (coordinate.getX() == i && coordinate.getY() == j) {
				return true;
			}
		}

		return false;
	}

}
