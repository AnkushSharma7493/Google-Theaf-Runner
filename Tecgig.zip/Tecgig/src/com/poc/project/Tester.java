package com.poc.project;

import java.io.File;
import java.io.IOException;

public class Tester {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String path="C:\\Users\\asharma430\\Documents\\DataFile.pdf";
		File file=new File(path);
		PDFReader pdf = new PDFReader();
		pdf.readFile(file);
	}

}
