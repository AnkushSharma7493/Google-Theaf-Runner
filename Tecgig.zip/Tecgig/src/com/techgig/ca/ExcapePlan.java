package com.techgig.ca;

import java.util.ArrayList;
import java.util.List;


public class ExcapePlan {
	/*
	 * ANKUSH SHARMA ALGORITHM USING DYNAMIC PROGRAMMING 
	 * STEP 0 : DEVELOP DATA STRUCTURE FOR THE PROBLEM.(MATRICX OF NODE TYPES), ALSO DEVELOP A SINGLETON
	 * OBJECT BuildingGraph AT APPLICATIONCONTEXT LEVEL,WHICH COMPRISES ALL LOCATION
	 * DETAIL FOR ALL THE THREADS :: O(NUMBER OF CELL). 
	 * Step 1 : CALCULATE THE RELATIVE MATRIX WRT SAFE LOCATION (Calculating distance of each cell from the
	 * safe location) :: TimeComplexity : O(NUMBER OF CELL). STEP 2 : CALCULATE MIN
	 * TIME FOR NICK TO REACH THE SAFE LOCATION CALLED NICKSAFETIME(Which is the
	 * relative matrix cell value itself) : O(1). STEP 3 : START THE COPS EXPANSION
	 * THREAD FOR THE TIME EQUALS TO NICKSAFETIME, WHICH MODIFY THE SINGLETION
	 * BUIDING OBJECT FOR COPS LOCATONS. STEP 3 : CHECK THE GENERATED MATRIX IF
	 * THERE IS ANY PATH EXIST FOR NICK TO REACH SAFE LOCATION, BY SIMPLE FOLLOWING
	 * THE DECENDING ORDER OF DISTANCE FROM SAFE LOCATION(CALCULATE IN STEP 2). STEP
	 * 4 : IF PATH DOES NOT EXIST, RETURN -1 STEP 5 : IF PATH EXIST , THEN CALL THE
	 * COPS THREAD FOR 1 MINUTE AND INCREMENT WAITING_TIME VARIABLE BY 1 AND CHECK
	 * AGAIN IF PATH EXIST, REPEAT UNTILL NICK GOT CAUGHT. STEP 6 : ONCE MATRIX
	 * STATE GENERATED IN WHICH THERE IS NO PATH EXIST BETWEEN NICK AND SAFE
	 * LOCATION, RETURN WAITINNG_TIME-1;
	 * 
	 */

	private static Coordinates Nicklocation;
	private static int truckCount;
	private static Coordinates safelocation;
	private static BuildingGraph buildingGraph;
	private static ArrayList<Coordinates> truckList = new ArrayList<>();
	private static int waitingTime = 0;
	private static ArrayList<Coordinates> copsLocation;

	/* INNER CLASSES DECALRATION STARTS */
	private class Coordinates {
		public Coordinates() {
		}

		public Coordinates(int x, int y) {
			super();
			X = x;
			Y = y;
		}

		private int X;
		private int Y;

		public int getX() {
			return X;
		}

		public void setX(int x) {
			X = x;
		}

		public int getY() {
			return Y;
		}

		public void setY(int y) {
			Y = y;
		}
	}

	private class Node {
		private Coordinates coordinate;
		private boolean visited;
		private Integer distance;
		private volatile Character value;
		private Coordinates relativeCoordinate;
		private int copArrivalTime;

		public Node() {
		}

		public Node(Coordinates coordinate) {
			super();
			this.coordinate = coordinate;
		}

		public Node(Coordinates coordinate, char value) {
			super();
			this.coordinate = coordinate;
			this.value = value;
		}

		public char getValue() {
			return value;
		}

		public void setValue(char value) {
			this.value = value;
		}

		public int getDistance() {
			return distance;
		}

		public void setDistance(int distance) {
			this.distance = distance;
		}

		public Coordinates getCoordinate() {
			return coordinate;
		}

		public void setCoordinate(Coordinates coordinate) {
			this.coordinate = coordinate;
		}

		public boolean isVisited() {
			return visited;
		}

		public void setVisited(boolean visited) {
			this.visited = visited;
		}

		public Coordinates getRelativeCoordinate() {
			return relativeCoordinate;
		}

		public void setRelativeCoordinate(Coordinates relativeCoordinate) {
			this.relativeCoordinate = relativeCoordinate;
		}

		public int getCopArrivalTime() {
			return copArrivalTime;
		}

		public void setCopArrivalTime(int copArrivalTime) {
			this.copArrivalTime = copArrivalTime;
		}

	}

	static private class BuildingGraph {
		private static final BuildingGraph buildingGraph;
		private static Node[][] buiding;
		private static int length;
		private static List<Node> shortestPath;
		private static Coordinates[] trucks;
		private static int stepsPerMinute;
		private static int waitingTime;
		private static Coordinates Nicklocation;
		private static Coordinates safelocation;
		private static int truckCount;
		private static boolean isPathExist = false;
		private static boolean canNickWait = false;
		private static int clockMinute;

		private BuildingGraph() {
		}

		static {
			buildingGraph = new BuildingGraph();
		}

		public static BuildingGraph getBuildingGraph(int size) {
			if (buildingGraph.buiding == null) {
				buildingGraph.buiding = new Node[size][size];
				buildingGraph.length = size;
			}
			return buildingGraph;
		}

		public static BuildingGraph getBuildingGraph(){
			if (buildingGraph.buiding == null) {
				return null;
			}
			return buildingGraph;
		}

		// create node and add into builder array
		public void addNode(int x, int y, char value) {
			buiding[x][y] = new ExcapePlan().new Node(new ExcapePlan().new Coordinates(x, y), value);
		}

		public Node getNode(int x, int y) {
			return buiding[x][y];
		}

		public Node getNode(Coordinates coordinates) {
			return buiding[coordinates.getX()][coordinates.getY()];
		}

		public int getLength() {
			return length;
		}

		public static List<Node> getShortestPath() {
			return shortestPath;
		}

		public static void setShortestPath(List<Node> shortestPath) {
			BuildingGraph.shortestPath = shortestPath;
		}

		public static Coordinates[] getTrucks() {
			return trucks;
		}

		public static void setTrucks(Coordinates trucks, int index) {
			BuildingGraph.trucks[index] = trucks;
		}

		public static int getStepsPerMinute() {
			return stepsPerMinute;
		}

		public static void setStepsPerMinute(int stepsPerMinute) {
			BuildingGraph.stepsPerMinute = stepsPerMinute;
		}

		public static int getWaitingTime() {
			return waitingTime;
		}

		public static void setWaitingTime(int waitingTime) {
			BuildingGraph.waitingTime = waitingTime;
		}

		public static void setLength(int length) {
			BuildingGraph.length = length;
		}

		public static Node[][] getBuiding() {
			return buiding;
		}

		public static void setBuiding(Node[][] buiding) {
			BuildingGraph.buiding = buiding;
		}

		public static Coordinates getNicklocation() {
			return Nicklocation;
		}

		public static void setNicklocation(Coordinates nicklocation) {
			Nicklocation = nicklocation;
		}

		public static Coordinates getSafelocation() {
			return safelocation;
		}

		public static void setSafelocation(Coordinates safelocation) {
			BuildingGraph.safelocation = safelocation;
		}

		public static void setTrucks(Coordinates[] trucks) {
			BuildingGraph.trucks = trucks;
		}

		public static int getTruckCount() {
			return truckCount;
		}

		public static void setTruckCount(int truckCount) {
			BuildingGraph.truckCount = truckCount;
		}

		public static boolean isPathExist() {
			return isPathExist;
		}

		public static void setPathExist(boolean isPathExist) {
			BuildingGraph.isPathExist = isPathExist;
		}

		public static int getClockMinute() {
			return clockMinute;
		}

		public static void setClockMinute(int clockMinute) {
			BuildingGraph.clockMinute = clockMinute;
		}
	}

	/* INNER CLASSES DECALRATION ENDS */

	public static int start(int size, int steps, String[] rows){
		// STEP 0
		initializeGrid(rows); 

		// STEP 1
		Node safe = buildingGraph.getNode(safelocation.getX(), safelocation.getY());
		safe.setDistance(0);
		safe.setVisited(true);
		calculateRelativeCoordinates(safe);

		// UPDATE THE SINGLETON BUILDING GRAPH OBJECT
		buildingGraph.setStepsPerMinute(steps);
		buildingGraph.setNicklocation(Nicklocation);
		buildingGraph.setSafelocation(safelocation);
		buildingGraph.setTruckCount(truckCount);

		// STEP2
		int NickSafeTime = (buildingGraph.getNode(buildingGraph.getNicklocation()).getDistance()
				+ buildingGraph.getStepsPerMinute() - 1) / buildingGraph.getStepsPerMinute();

		// STEP 3
		copsLocation = new ArrayList<>();
		copsLocation.addAll(truckList);
		checkCopsSpreadRate(NickSafeTime);
		
		// STEP 4
		findAllPaths(buildingGraph.getNode(Nicklocation));

		// STEP 5
		if (!BuildingGraph.getBuildingGraph().isPathExist()) {
			return -1;
		}
		
		// STEP 6
		while (BuildingGraph.getBuildingGraph().isPathExist()) {
			checkNickLuckForNextMinute();
		}

		// STEP 7
		return --waitingTime;

	}

	public static void initializeGrid(String[] rows) {
		buildingGraph = BuildingGraph.getBuildingGraph(rows.length);
		for (int i = 0; i < rows.length; i++) {
			char[] temp = rows[i].toCharArray();
			for (int j = 0; j < temp.length; j++) {
				switch (temp[j]) {
				case 'M':
					Nicklocation = new ExcapePlan().new Coordinates(i, j);
					break;
				case 'L':
					// buildingGraph.setTrucks(new Coordinates(i, j), truckCount);
					truckList.add(new ExcapePlan().new Coordinates(i, j));
					truckCount++;
					break;
				case 'S':
					safelocation = new ExcapePlan().new Coordinates(i, j);
					break;
				}
				buildingGraph.addNode(i, j, temp[j]);
			}
		}
	}

	// Calculate the relative coordinate wrt safe location
	public static void calculateRelativeCoordinates(Node safe) {
		for (int i = 0; i < buildingGraph.getLength(); i++) {
			for (int j = 0; j < buildingGraph.getLength(); j++) {
				Node node = buildingGraph.getNode(i, j);
				node.setRelativeCoordinate(
						new ExcapePlan().new Coordinates(Math.abs(node.getCoordinate().getX() - safe.getCoordinate().getX()),
								Math.abs(node.getCoordinate().getY() - safe.getCoordinate().getY())));
				node.setDistance(node.getRelativeCoordinate().getX() + node.getRelativeCoordinate().getY());
			}
		}
		safe.setRelativeCoordinate(new ExcapePlan().new Coordinates(0, 0));
	}

	public static void checkCopsSpreadRate(int time) {
				for (int currentMinute = 1; currentMinute <= time; currentMinute++) {
					buildingGraph.setClockMinute(buildingGraph.getClockMinute() + 1);
					for (Coordinates coordinates : copsLocation) {
						setCop(coordinates);
					}
				}
	}
	public static void setCop(Coordinates truck) {
		// check right
		if (truck.getY() + 1 < buildingGraph.getLength()) {
			locateCop(truck.getX(), truck.getY() + 1);
		}
		// check left
		if (truck.getY() - 1 >= 0) {
			locateCop(truck.getX(), truck.getY() - 1);
		}

		// check up
		if (truck.getX() - 1 >= 0) {
			locateCop(truck.getX() - 1, truck.getY());
		}

		// check down
		if (truck.getX() + 1 < buildingGraph.getLength()) {
			locateCop(truck.getX() + 1, truck.getY());
		}
	}

	public static void locateCop(int x, int y) {
		if ((buildingGraph.getNode(x, y).getValue() == 'O' || buildingGraph.getNode(x, y).getValue() == 'M')
				&& !buildingGraph.getNode(x, y).isVisited()) {
			buildingGraph.getNode(x, y).setValue('C');
			buildingGraph.getNode(x, y).setCopArrivalTime(buildingGraph.getClockMinute());
			buildingGraph.getNode(x, y).setVisited(true);
			copsLocation.add(new ExcapePlan().new Coordinates(x, y));
		}
	}

	public static void findAllPaths(Node source) {
		// check left
		if (source.getCoordinate().getY() - 1 >= 0
				&& buildingGraph.getNode(source.getCoordinate().getX(), source.getCoordinate().getY() - 1)
						.getDistance() < source.getDistance()) {
			processPath(source.getCoordinate().getX(), source.getCoordinate().getY() - 1);
		}
		// check right
		if (source.getCoordinate().getY() + 1 < buildingGraph.getLength()
				&& buildingGraph.getNode(source.getCoordinate().getX(), source.getCoordinate().getY() + 1)
						.getDistance() < source.getDistance()) {
			processPath(source.getCoordinate().getX(), source.getCoordinate().getY() + 1);
		}
		// check up
		if (source.getCoordinate().getX() - 1 >= 0
				&& buildingGraph.getNode(source.getCoordinate().getX() - 1, source.getCoordinate().getY())
						.getDistance() < source.getDistance()) {
			processPath(source.getCoordinate().getX() - 1, source.getCoordinate().getY());
		}
		// check down
		if (source.getCoordinate().getX() + 1 < buildingGraph.getLength()
				&& buildingGraph.getNode(source.getCoordinate().getX() + 1, source.getCoordinate().getY())
						.getDistance() < source.getDistance()) {
			processPath(source.getCoordinate().getX() + 1, source.getCoordinate().getY());
		}
	}

	private static void processPath(int x, int y) {
		if ((buildingGraph.getNode(x, y).getValue() == 'O' || buildingGraph.getNode(x, y).getValue() == 'C'
				|| buildingGraph.getNode(x, y).getValue() == 'S') && !buildingGraph.isPathExist()) {
			if (buildingGraph.getNode(x, y).getValue() == 'S') {
				buildingGraph.setPathExist(true);
			}

			if ((buildingGraph.getNode(x, y).getValue() == 'C' && buildingGraph.getNode(x, y)
					.getCopArrivalTime() > Math.abs(buildingGraph.getNode(Nicklocation).getDistance()
							- buildingGraph.getNode(x, y).getDistance()) + waitingTime)
					|| (buildingGraph.getNode(x, y).getValue() == 'O')) {
				findAllPaths(buildingGraph.getNode(x, y));
			}

		}
	}
	public static void checkNickLuckForNextMinute(){
		waitingTime++;
		checkCopsSpreadRate(1);
		BuildingGraph.setPathExist(false);
		findAllPaths(buildingGraph.getNode(Nicklocation));
	}
	
	//Debugging method

	public static void showBuilding() throws Exception {
		System.out.println();
		for (int i = 0; i < buildingGraph.getLength(); i++) {
			for (int j = 0; j < buildingGraph.getLength(); j++) {
				if (buildingGraph.getNode(i, j).getValue() == 'M' || buildingGraph.getNode(i, j).getValue() == 'S'
						|| buildingGraph.getNode(i, j).getValue() == 'L' || buildingGraph.getNode(i, j).getValue() == 'H' || buildingGraph.getNode(i, j).getValue() == 'C') {
					System.out.print(buildingGraph.getNode(i, j).getValue()+ "	");
				}else {
				System.out.print(buildingGraph.getNode(i, j).getDistance() + "	");}
			}
			System.out.println();
		}
	}
}
