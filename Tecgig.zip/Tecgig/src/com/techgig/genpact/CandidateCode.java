package com.techgig.genpact;

import java.awt.List;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class CandidateCode {
	private static int[] grades = new int[] { 10, 9, 8, 7, 6, 5 };
	private static Integer[][] marks;
	private static Integer[] credits;
	private static int numberOfSubjects;
	private static Set<Integer> distinctTotal = new HashSet<>();
	private static int currentPointer = 0;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		numberOfSubjects = sc.nextInt();
		credits = new Integer[numberOfSubjects];
		marks = new Integer[numberOfSubjects][grades.length];

		for (int i = 0; i < numberOfSubjects; i++) {
			credits[i] = sc.nextInt();
		}
		
		computeMatrix();
		

		for (int mark : marks[currentPointer]) {
			if (numberOfSubjects == 1) {
				distinctTotal.add(mark);
			} else {
				distinctTotal.addAll(getAllMarks(mark,1+currentPointer));
			}
		}

		System.out.println(distinctTotal.size());
	}

	private static Set getAllMarks(int mark,int pointer) {
		if (pointer < numberOfSubjects-1) {
			for (int subjectMark : marks[pointer]) {
				distinctTotal.addAll(getAllMarks(mark+subjectMark,pointer+1));
			}
		} else if (pointer == numberOfSubjects-1) {
			Integer[] marksTotal = new Integer[grades.length];
			for (int i = 0; i < grades.length; i++) {
				System.out.println(pointer);
				marksTotal[i] = marks[pointer][i] + mark;
			}
			return new HashSet(Arrays.asList(marksTotal));
		}
		return distinctTotal;
	}


	
	private static void computeMatrix() {
		int[] product;
		// calculate the martix for each subject possible marks
		for (int i = 0; i < marks.length; i++) {
					for (int l = 0; l < grades.length; l++) {
						marks[i][l] = credits[i] * grades[l];
					}
		}
	}

}
